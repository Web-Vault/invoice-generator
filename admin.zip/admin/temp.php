<?php
require_once "../modules/app/connect.php";
require_once "../modules/app/invoice.php";

$invoice_id = $_REQUEST['invoice_id'];


$conn = new connect();
$invoice = new Invoice();

$invoice_info = $invoice->fetch_invoice($invoice_id);


$currencyMap = [
        "INR" => "INR ",
        "EUR" => "€",
        "GBP" => "£",
        "USD" => "$",
        "AUD" => "A$",
        "CAD" => "C$",
        "JPY" => "¥",
        "CNY" => "¥",
        "CHF" => "CHF",
        "SGD" => "S$",
        "NZD" => "NZ$",
        "HKD" => "HK$",
        "SEK" => "kr",
        "NOK" => "kr",
        "KRW" => "₩",
        "ZAR" => "R",
        "BRL" => "R$",
        "MXN" => "$",
        "RUB" => "₽",
        "MYR" => "RM",
        "IDR" => "Rp"
];

$current_currency = $currencyMap[$invoice_info['currency']];
?>

<!-- Bootstrap -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz"
        crossorigin="anonymous"></script>

<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"
        integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r"
        crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.min.js"
        integrity="sha384-0pUGZvbkm6XF6gxjEnlmuGrJXVbNuzT9qBBavbLwCsOGabYfZo0T0to5eqruptLy"
        crossorigin="anonymous"></script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>


<!-- Bootstrap Bundle with Popper -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>


<!-- FontAwsome -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.1/css/all.min.css"
        integrity="sha512-5Hs3dF2AEPkpNAR7UiOHba+lRSJNeM2ECkwxUIxC1Q/FLycGTbNapWXB4tP889k5T5Ju8fs4b1P5z/iB4nMfSQ=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />

<!-- JQuery -->
<script src="https://code.jquery.com/jquery-3.7.1.js" integrity="sha256-eKhayi8LEQwp4NKxN+CfCh+3qOVUtJn3QNZ0TciWLP4="
        crossorigin="anonymous"></script>




<div class="container my-5 p-0">
        <div class="card mt-sm-3 pb-8">
                <div class="p-5 pb-0">
                        <div class="row align-items-center">
                                <div class="col-sm mb-2 mb-sm-0">

                                        <div class="d-sm-flex align-items-sm-center"><button class="btn border mx-2">
                                                        <a href="index.php"
                                                                class="text-secondary text-decoration-none"><i
                                                                        class="fa-solid fa-arrow-left fs-6 text-secondary fw-bold"></i></a>
                                                </button>
                                                <h1 class="page-header-title">Invoice
                                                        #<?php echo $invoice_info['invoice_id']; ?></h1>
                                                <span class="ms-2 ms-sm-3">
                                                        <i class="fas fa-calendar-alt"></i>
                                                        <?php echo $invoice_info['invoice_date']; ?>
                                                </span>
                                                <span class="ms-2 ms-sm-3">
                                                        <i class="fas fa-user"></i>
                                                        <?php echo $invoice_info['bill_to']; ?>
                                                </span>
                                        </div>
                                </div>
                        </div>

                        <div class="row" style="margin-left: 70px;">
                                <button class="btn btn-md btn-success d-flex justify-content-between align-items-center"
                                        style="width: auto;">
                                        <i class="fa-solid fa-arrow-down"></i>
                                        <span class="btn-title mx-2"> <a class="text-white text-decoration-none"
                                                        href="../modules/invoice/download.php?invoice_id=<?php echo $invoice_info['invoice_id']; ?>">
                                                        Download </a> </span>
                                </button>
                                <button class="btn btn-md btn-primary d-flex justify-content-between align-items-center ms-3 mx-2"
                                        style="width: auto;">
                                        <!-- <i class="fa-brands fa-facebook-f"></i> -->
                                        <span class="btn-title mx-2"> Share</span>
                                </button>
                        </div>
                </div>
                <hr />
                <div class="row px-1">
                        <div class="col-md-6 px-md-5 pt-5">
                                <div style="max-width: 350px;">
                                        <img src="company_logo/<?php echo $invoice_data['invoice_logo']; ?>"
                                                class="img-fluid" style="max-height: 100px;" />
                                </div>
                                <div class="mt-3">
                                        <div class="text-dark"><?php echo $invoice_info['invoice_from']; ?>
                                        </div>
                                </div>
                        </div>
                        <div class="col-md-6 text-end pt-5 pe-md-5 text-dark">
                                <div class="display-5"><?php echo $invoice_info['company_name']; ?></div>
                                <div class="fs-3 text-secondary">
                                        #<?php echo $invoice_info['invoice_id']; ?></div>
                        </div>
                </div>
                <div class="row mt-3 px-1">
                        <div class="col-md-8 px-md-5">
                                <div class="row">
                                        <div class="col-md-6">
                                                <div class="mt-3">
                                                        <div class="fs-6 text-secondary">Bill To</div>
                                                        <div class="text-dark">
                                                                <?php echo $invoice_info['bill_to']; ?>
                                                        </div>
                                                </div>
                                        </div>
                                        <div class="col-md-6">
                                                <div class="mt-3">
                                                        <div class="fs-6 text-secondary">Ship To</div>
                                                        <div class="text-dark">
                                                                <?php echo $invoice_info['ship_to']; ?>
                                                        </div>
                                                </div>
                                        </div>
                                </div>
                        </div>
                        <div class="col-md-4 px-md-5 mt-3 mt-md-0">
                                <div class="row mt-3">
                                        <div class="col-auto fs-6 text-secondary">Date</div>
                                        <div class="col text-end">
                                                <?php echo $invoice_info['invoice_date']; ?>
                                        </div>
                                </div>
                                <div class="row mt-3">
                                        <div class="col-auto fs-6 text-secondary">Payment Terms</div>
                                        <div class="col text-end">
                                                <?php echo $invoice_info['payment_terms']; ?>
                                        </div>
                                </div>
                                <div class="row mt-3">
                                        <div class="col-auto fs-6 text-secondary">Due Date</div>
                                        <div class="col text-end"><?php echo $invoice_info['due_date']; ?>
                                        </div>
                                </div>
                                <div class="row mt-3">
                                        <div class="col-auto fs-6 text-secondary">PO Number</div>
                                        <div class="col text-end"><?php echo $invoice_info['po_number']; ?>
                                        </div>
                                </div>
                        </div>
                </div>
                <div class="table-responsive mx-5 mt-5">
                        <table class="table table-borderless border-top table-thead-bordered">
                                <thead class="thead-light">
                                        <tr>
                                                <th class="ps-md-7">Item</th>
                                                <th class="text-end">Quantity</th>
                                                <th class="text-end">Rate</th>
                                                <th class="text-end pe-md-7">Amount</th>
                                        </tr>
                                </thead>
                                <tbody>
                                        <?php foreach ($invoice_info['items'] as $item): ?>
                                                <tr>
                                                        <td class="ps-md-7">
                                                                <div><?= htmlspecialchars($item['item_name']); ?></div>
                                                        </td>
                                                        <td class="text-end"><?= htmlspecialchars($item['item_quantity']); ?>
                                                        </td>
                                                        <td class="text-end">
                                                                <?php
                                                                echo "<span style='font-family: Arial Unicode MS;'>" .
                                                                        ($current_currency === "INR " ? "₹ " : $current_currency) .
                                                                        "</span>";
                                                                ?>
                                                                <?= htmlspecialchars(number_format($item['item_amount'], 2)); ?>
                                                        </td>
                                                        <td class="text-end pe-md-7">
                                                                <?php
                                                                echo "<span style='font-family: Arial Unicode MS;'>" .
                                                                        ($current_currency === "INR " ? "₹ " : $current_currency) .
                                                                        "</span>";
                                                                ?>
                                                                <?= htmlspecialchars(number_format($item['item_total'], 2)); ?>
                                                        </td>
                                                </tr>
                                        <?php endforeach; ?>
                                </tbody>
                                <tfoot>
                                        <tr>
                                                <td colspan="2"></td>
                                                <td class="text-end ps-3 border-top">Subtotal</td>
                                                <td class="text-end border-top pe-md-7">
                                                        <?php
                                                        echo "<span style='font-family: Arial Unicode MS;'>" .
                                                                ($current_currency === "INR " ? "₹ " : $current_currency) .
                                                                "</span>";
                                                        ?> <?php echo $invoice_info['subtotal']; ?>
                                                </td>
                                        </tr>
                                        <tr>
                                                <td colspan="2"></td>
                                                <td class="text-end ps-3">Discount</td>
                                                <td class="text-end pe-md-7">
                                                        <?php
                                                        echo "<span style='font-family: Arial Unicode MS;'>" .
                                                                ($current_currency === "INR " ? "₹ " : $current_currency) .
                                                                "</span>";
                                                        ?><?php echo $invoice_info['discount']; ?>
                                                </td>
                                        </tr>
                                        <tr>
                                                <td colspan="2"></td>
                                                <td class="text-end ps-3">Tax</td>
                                                <td class="text-end pe-md-7">
                                                        <?php
                                                        echo "<span style='font-family: Arial Unicode MS;'>" .
                                                                ($current_currency === "INR " ? "₹ " : $current_currency) .
                                                                "</span>";
                                                        ?><?php echo $invoice_info['tax_charge']; ?>
                                                </td>
                                        </tr>
                                        <tr>
                                                <td colspan="2"></td>
                                                <td class="text-end ps-3">Shipping</td>
                                                <td class="text-end pe-md-7">
                                                        <?php
                                                        echo "<span style='font-family: Arial Unicode MS;'>" .
                                                                ($current_currency === "INR " ? "₹ " : $current_currency) .
                                                                "</span>";
                                                        ?><?php echo $invoice_info['shipping_charge']; ?>
                                                </td>
                                        </tr>
                                        <tr>
                                                <td colspan="2"></td>
                                                <td class="text-end ps-3 border-top fw-bold">Total</td>
                                                <td class="text-end border-top fw-bold pe-md-7">
                                                        <?php
                                                        echo "<span style='font-family: Arial Unicode MS;'>" .
                                                                ($current_currency === "INR " ? "₹ " : $current_currency) .
                                                                "</span>";
                                                        ?><?php echo $invoice_info['total_amount']; ?>
                                                </td>
                                        </tr>
                                        <tr>
                                                <td colspan="2"></td>
                                                <td class="text-end ps-3">Amount Paid</td>
                                                <td class="text-end pe-md-7">
                                                        <?php
                                                        echo "<span style='font-family: Arial Unicode MS;'>" .
                                                                ($current_currency === "INR " ? "₹ " : $current_currency) .
                                                                "</span>";
                                                        ?> <?php echo $invoice_info['paid_amount']; ?>
                                                </td>
                                        </tr>
                                        <tr>
                                                <td colspan="2"></td>
                                                <td class="text-end ps-3 fw-bold">Balance Due</td>
                                                <td class="text-end pe-md-7 fw-bold">
                                                        <?php
                                                        echo "<span style='font-family: Arial Unicode MS;'>" .
                                                                ($current_currency === "INR " ? "₹ " : $current_currency) .
                                                                "</span>";
                                                        ?><?php echo $invoice_info['remainig_amount']; ?>
                                                </td>
                                        </tr>
                                </tfoot>
                        </table>
                </div>
                <div class="mt-3 px-5 px-md-8">
                        <div class="fs-6 text-secondary">Notes</div>
                        <div><?php echo $invoice_info['notes']; ?></div>
                </div>
                <div class="my-5 px-5 px-md-8">
                        <div class="fs-6 text-secondary">Terms</div>
                        <div><?php echo $invoice_info['terms']; ?></div>
                </div>
        </div>
</div>